var menudata = [{
    id: "0.1",
    text: "Jquery Plugins",
    hasChildren: true,
    isexpand: true,
    complete: true,
    ChildNodes: [{
        id: "0.1.1",
        text: "Date Picker",
        hasChildren: true,
        isexpand: false,
        complete: true,
        ChildNodes: [{
            id: "0.1.1.1",
            text: "Samples vs Code",
            value: "wdDatePicker/sample.htm",
            hasChildren: false,
            isexpand: false,
            complete: true,
            ChildNodes: null
        }]
    },
    {
        id: "0.1.3",
        text: "Checkbox Tree",
        hasChildren: true,
        isexpand: false,
        complete: true,
        ChildNodes: [{
            id: "0.1.3.1",
            text: "Huge Data Tree",
            value: "wdTree/huge-data-tree-sample.htm",
            hasChildren: false,
            isexpand: false,
            complete: true,
            ChildNodes: null
        },
        {
            id: "0.1.3.2",
            text: "Lazy Load Tree",
            value: "wdTree/lazy-load-tree-sample.htm",
            hasChildren: false,
            isexpand: false,
            complete: true,
            ChildNodes: null
}]
        },
    {
        id: "0.1.4",
        text: "Context Menu",
        hasChildren: true,
        isexpand: false,
        complete: true,
        ChildNodes: [{
            id: "0.1.4.1",
            text: "Samples vs Code",
            value: "wdContentMenu/sample.htm",
            hasChildren: false,
            isexpand: false,
            complete: true,
            ChildNodes: null
}]
        }]
}];