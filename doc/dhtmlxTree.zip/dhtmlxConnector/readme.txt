dhtmlxConnector is available for different server side platforms. 
Please visit its home page to learn more and download necessary package.

http://www.dhtmlx.com/docs/products/dhtmlxConnector/index.shtml