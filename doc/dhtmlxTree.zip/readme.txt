dhtmlxTree v.2.6  Standard edition build 100916 (with applied IE9 beta fix)

(c) DHTMLX Ltd. 