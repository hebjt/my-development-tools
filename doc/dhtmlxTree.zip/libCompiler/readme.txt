(c) DHTMLX Ltd.

This tool can combine numerous script files of DHTMLX library into a single JS file (+ single CSS file) depending on chosen functionality. 
To use this tool, you need to unzip dhtmlxSuite package content into directory under web server with support for PHP and load [dhtmlxSuitePackage]/libCompiler/index.html. Currently there is no difference between libCompiler delivered with Standard and Professional Editions of dhtmlxSuite, but resulting files functionality depends on Edition of course.
More details about usage of libCompiler can be found here: http://www.dhtmlx.com/docs/products/docsExplorer/index.shtml?node=libc_